# USB Host Library Rev.2.0

The code is released under the GNU General Public License.
__________
[![Build Status](https://travis-ci.org/felis/USB_Host_Shield_2.0.svg?branch=master)](https://travis-ci.org/felis/USB_Host_Shield_2.0)

# Documentation

The documenation is automatically build using [Travis](https://travis-ci.com/) and hosted using [Github Pages](https://help.github.com/categories/github-pages-basics/).

The library documentation is generated using [Doxygen](http://www.stack.nl/~dimitri/doxygen/) and can be found at the following link: <https://felis.github.io/USB_Host_Shield_2.0/>.
